Hitachi.Raidcom collection plugins directory
├── module_utils
    ├── hitachi_raidcom_utility_parser.py
    ├── hitachi_raidcom_utility.py
    └── hitachi_raidcom.py
└── modules
    └── hur.py